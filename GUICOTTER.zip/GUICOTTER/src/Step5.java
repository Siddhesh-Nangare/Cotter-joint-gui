//package app;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Step5 extends JFrame {
    JTextField s1,s2,s3,s4,s5,s6,s7,saz8,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
    JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
    
    Step5(String d2, String d1, String d3, String d4, String t12, String a, String b){
        setBounds(300,0,700,790);
        getContentPane().setBackground(Color.white);
        setLayout(null);
        setVisible(true);

        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("img/Cotter Joint.png"));
        JLabel k1=new JLabel(i1);
        k1.setBounds(10,10,700,400);
        add(k1);
        //d1,d2,d3,d4,a,b,c,t1
        JLabel l4=new JLabel(" Outer Diameter of Socket(d1) ");
        l4.setFont(new Font("Arial",Font.PLAIN, 15));
        l4.setForeground(Color.black);
        l4.setBounds(20, 420,700, 30);
        add(l4);
        t1=new JTextField(d1);
        t1.setBounds(270,420,120,25);
        t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t1);
        JLabel l5=new JLabel(" Inner Diameter of Socket(d2) ");
        l5.setFont(new Font("Arial",Font.PLAIN, 15));
        l5.setForeground(Color.black);
        l5.setBounds(20, 450,700, 30);
        add(l5);
        t2=new JTextField(d2);
        t2.setBounds(270,450,120,25);
        t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t2);
        JLabel l6=new JLabel(" Outer Diameter of Spigot Coller(d3) ");
        l6.setFont(new Font("Arial",Font.PLAIN, 15));
        l6.setForeground(Color.black);
        l6.setBounds(20, 480,700, 30);
        add(l6);
        t3=new JTextField(d3);
        t3.setBounds(270,480,120,25);
        t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t3);
        JLabel l7=new JLabel(" Diameter of Socket Coller(d4) ");
        l7.setFont(new Font("Arial",Font.PLAIN, 15));
        l7.setForeground(Color.black);
        l7.setBounds(20, 510,700, 30);
        add(l7);
        t4=new JTextField(d4);
        t4.setBounds(270,510,120,25);
        t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t4);
        JLabel l8=new JLabel(" Thickness of Spigot Coller(t1) ");
        l8.setFont(new Font("Arial",Font.PLAIN, 15));
        l8.setForeground(Color.black);
        l8.setBounds(20, 540,700, 30);
        add(l8);
        t5=new JTextField(t12);
        t5.setBounds(270,540,120,25);
        t5.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t5);
        JLabel l9=new JLabel("Width of Cotter(b) ");
        l9.setFont(new Font("Arial",Font.PLAIN, 15));
        l9.setForeground(Color.black);
        l9.setBounds(20, 570,700, 30);
        add(l9);
        t6=new JTextField(b);
        t6.setBounds(270,570,120,25);
        t6.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t6);
        JLabel l1=new JLabel(" a & c = ");
        l1.setFont(new Font("Arial",Font.PLAIN, 15));
        l1.setForeground(Color.black);
        l1.setBounds(20, 600,700, 30);
        add(l1);
        t7=new JTextField(a);
        t7.setBounds(270,600,120,25);
        t7.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t7);
    // }
    // public static void main(String[] args) {
    //     new Step5();
    // }
 

    }
}