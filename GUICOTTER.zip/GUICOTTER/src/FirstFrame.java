//package app;
import javax.swing.JFrame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FirstFrame extends JFrame implements ActionListener{
    JButton b1,b2;
    JTextField t1;
    public FirstFrame(){
        setBounds(200,50,700,600);
        getContentPane().setBackground(Color.white);
        setLayout(null);
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("img/img3.png"));
        JLabel l1=new JLabel(i1);
        l1.setBounds(30,300,600,250);
        add(l1);
       

        JLabel l3=new JLabel("GUI of Cotter Joint");
        l3.setFont(new Font("Algerian",Font.BOLD, 45));
        l3.setForeground(Color.RED);
        l3.setBounds(130, 80, 500, 70);
        add(l3);
        JLabel l4=new JLabel("Enter your Name");
        l4.setFont(new Font("Time New Roman",Font.BOLD, 15));
        l4.setForeground(Color.BLUE);
        l4.setBounds(300, 150,300,40);
        add(l4);

        t1=new JTextField();
        t1.setBounds(150,200,400,25);
        t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t1);

        b1= new JButton("Start Design");
        b1.setBounds(150,250,150,30);
        b1.setBackground(Color.pink);
        b1.addActionListener(this);
        add(b1);
        b2= new JButton("Exit");
        b2.setBounds(400,250,150,30);
        b2.setBackground(Color.pink);
        add(b2);
        b2.addActionListener(this);

        
        setVisible(true);
    }
    public static void main(String[] args) {
        new FirstFrame();
    }

    

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1){
            String name=t1.getText();
            this.setVisible(false);
            new Design(name);
        }
        if(e.getSource()==b2){
            System.exit(0);
        }
        
    }
}
