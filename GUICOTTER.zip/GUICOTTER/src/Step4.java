//package app;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Step4 extends JFrame implements ActionListener{
    JTextField s1,s2,s3,s4,s5,s6,s7,s8,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;
    JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
    
    Step4(String stress,String cr,String sh, String ct,String cs,String load,String d2,String t){
        setBounds(300,0,700,790);
        getContentPane().setBackground(Color.white);
        setLayout(null);
        setVisible(true);
        JLabel l9=new JLabel("Stresses are ");
        l9.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l9.setForeground(Color.blue);
        l9.setBounds(20, 10,700, 30);
        add(l9);
        s1=new JTextField(stress);
        s1.setBounds(120,10,100,25);
        s1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s1);
        s2=new JTextField(cr);
        s2.setBounds(230,10,100,25);
        s2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s2);
        s3=new JTextField(sh);
        s3.setBounds(340,10,100,25);
        s3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s3);
        s4=new JTextField(ct);
        s4.setBounds(450,10,100,25);
        s4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s4);
        s5=new JTextField(cs);
        s5.setBounds(560,10,100,25);
        s5.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s5);
        JLabel l1=new JLabel("Load = ");
        l1.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l1.setForeground(Color.blue);
        l1.setBounds(20, 40,700, 30);
        add(l1);
        s6=new JTextField(load);
        s6.setBounds(120,40,100,25);
        s6.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s6);
        JLabel l2=new JLabel("d2 =");
        l2.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l2.setForeground(Color.blue);
        l2.setBounds(300, 40,700, 30);
        add(l2);
        s7=new JTextField(d2);
        s7.setBounds(350,40,100,25);
        s7.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s7);
        JLabel l3=new JLabel("t = ");
        l3.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l3.setForeground(Color.blue);
        l3.setBounds(510, 40,700, 30);
        add(l3);
        s8=new JTextField(t);
        s8.setBounds(550,40,100,25);
        s8.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s8);

        b1= new JButton("next");
        b1.setBounds(570,610,80, 25);
        b1.setBackground(Color.cyan);
        b1.addActionListener(this);
        add(b1);

        JLabel l5=new JLabel("Step 4 - Failure of Socket in Tension ");
        l5.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l5.setForeground(Color.blue);
        l5.setBounds(30, 80,700, 30);
        add(l5);
        JLabel l4=new JLabel(" Outer Diameter of Socket(d1) ");
        l4.setFont(new Font("Arial",Font.PLAIN, 15));
        l4.setForeground(Color.black);
        l4.setBounds(20, 120,700, 30);
        add(l4);
        b2= new JButton("Calculate");
        b2.setBounds(450, 120,80, 25);
        b2.setBackground(Color.pink);
        b2.addActionListener(this);
        add(b2);
        t1=new JTextField();
        t1.setBounds(270,120,120,25);
        t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t1);

        JLabel l6=new JLabel("Step 5 - Failure of Cotter in Shear ");
        l6.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l6.setForeground(Color.blue);
        l6.setBounds(30, 160,700, 30);
        add(l6);
        JLabel l7=new JLabel("Width of Cotter (b)");
        l7.setFont(new Font("Arial",Font.PLAIN, 15));
        l7.setForeground(Color.black);
        l7.setBounds(20, 200,700, 30);
        add(l7);
        b3= new JButton("Calculate");
        b3.setBounds(450, 200,80, 25);
        b3.setBackground(Color.pink);
        b3.addActionListener(this);
        add(b3);
        t2=new JTextField();
        t2.setBounds(270,200,120,25);
        t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t2);

        JLabel l8=new JLabel("Step 6 - Failure of Socket Cotter in Crushing");
        l8.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l8.setForeground(Color.blue);
        l8.setBounds(30, 240,700, 30);
        add(l8);
        JLabel q9=new JLabel("Socket Cotter Diameter (d4))");
        q9.setFont(new Font("Arial",Font.PLAIN, 15));
        q9.setForeground(Color.black);
        q9.setBounds(20, 290,700, 30);
        add(q9);
        b4= new JButton("Calculate");
        b4.setBounds(450, 290,80, 25);
        b4.setBackground(Color.pink);
        b4.addActionListener(this);
        add(b4);
        t3=new JTextField();
        t3.setBounds(270,290,120,25);
        t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t3);

        JLabel q1=new JLabel("Step 7 - Failure of Socket end in Shearing ");
        q1.setFont(new Font("Times New Roman",Font.BOLD, 18));
        q1.setForeground(Color.blue);
        q1.setBounds(30, 330,700, 30);
        add(q1);
        JLabel q2=new JLabel("c  = ");
        q2.setFont(new Font("Arial",Font.PLAIN, 15));
        q2.setForeground(Color.black);
        q2.setBounds(20, 360,700, 30);
        add(q2);
        b5= new JButton("Calculate");
        b5.setBounds(450, 360,80, 25);
        b5.setBackground(Color.pink);
        b5.addActionListener(this);
        add(b5);
        t4=new JTextField();
        t4.setBounds(270,370,120,25);
        t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t4);
        
        JLabel q3=new JLabel("Step 8 - Failure of rod end in Shearing ");
        q3.setFont(new Font("Times New Roman",Font.BOLD, 18));
        q3.setForeground(Color.blue);
        q3.setBounds(30, 390,700, 30);
        add(q3);
        JLabel q4=new JLabel("a  = ");
        q4.setFont(new Font("Arial",Font.PLAIN, 15));
        q4.setForeground(Color.black);
        q4.setBounds(20, 430,700, 30);
        add(q4);
        b6= new JButton("Calculate");
        b6.setBounds(450, 430,80, 25);
        b6.setBackground(Color.pink);
        b6.addActionListener(this);
        add(b6);
        t5=new JTextField();
        t5.setBounds(270,430,120,25);
        t5.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t5);

        JLabel q5=new JLabel("Step 9 - Failure of Spigot Coller in Crushing ");
        q5.setFont(new Font("Times New Roman",Font.BOLD, 18));
        q5.setForeground(Color.blue);
        q5.setBounds(30, 455,700, 30);
        add(q5);
        JLabel q6=new JLabel("Spigot coller diameter(d3)  = ");
        q6.setFont(new Font("Arial",Font.PLAIN, 18));
        q6.setForeground(Color.black);
        q6.setBounds(20, 490,700, 30);
        add(q6);
        b7= new JButton("Calculate");
        b7.setBounds(450, 490,80, 25);
        b7.setBackground(Color.pink);
        b7.addActionListener(this);
        add(b7);
        t6=new JTextField();
        t6.setBounds(270,490,120,25);
        t6.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t6);
        
        JLabel q7=new JLabel("Step 10 - Failure of Spigot Coller in Shearing ");
        q7.setFont(new Font("Times New Roman",Font.BOLD, 18));
        q7.setForeground(Color.blue);
        q7.setBounds(30, 530,700, 30);
        add(q7);
        JLabel q8=new JLabel("Thickness of Spigot Coller(t1)");
        q8.setFont(new Font("Arial",Font.PLAIN, 18));
        q8.setForeground(Color.black);
        q8.setBounds(20, 565,700, 30);
        add(q8);
        b8= new JButton("Calculate");
        b8.setBounds(450, 565,80, 25);
        b8.setBackground(Color.pink);
        b8.addActionListener(this);
        add(b8);
        t7=new JTextField();
        t7.setBounds(270,565,120,25);
        t7.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t7);

        JLabel q10=new JLabel("Step 11 - Failure of Coller in Bending");
        q10.setFont(new Font("Times New Roman",Font.BOLD, 18));
        q10.setForeground(Color.blue);
        q10.setBounds(30, 595,700, 30);
        add(q10);
        JLabel q11=new JLabel("Bending Stress");
        q11.setFont(new Font("Arial",Font.PLAIN, 18));
        q11.setForeground(Color.black);
        q11.setBounds(20, 620,700, 30);
        add(q11);
        b9= new JButton("Calculate");
        b9.setBounds(450, 620,80, 25);
        b9.setBackground(Color.pink);
        b9.addActionListener(this);
        add(b9);
        t8=new JTextField();
        t8.setBounds(270,620,120,25);
        t8.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t8);

        JLabel a1=new JLabel(" Design is safe or Not  ");
        a1.setFont(new Font("Arial",Font.PLAIN, 18));
        a1.setForeground(Color.black);
        a1.setBounds(20, 650,700, 30);
        add(a1);
        t9=new JTextField();
        t9.setBounds(250,650,190,25);
        t9.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t9);
        b10= new JButton("Check");
        b10.setBounds(450, 650,80, 25);
        b10.setBackground(Color.pink);
        b10.addActionListener(this);
        add(b10);
        JLabel a2=new JLabel("After changing dimensions b is  =");
        a2.setFont(new Font("Arial",Font.PLAIN, 18));
        a2.setForeground(Color.black);
        a2.setBounds(20, 690,700, 30);
        add(a2);
        t10=new JTextField();
        t10.setBounds(350,690,190,25);
        t10.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t10);
        
        
       
        

    }
    // public static void main(String[]args){
    //     new Step4("","","","","","","","");
    // }
	@Override
	public void actionPerformed(ActionEvent e) {
       String sdt,t,d2,load,cds,sdcr,sds,cdt,D1,D3,D4,T1,A,B;
       sdt=s1.getText();
       t=s8.getText();
       d2=s7.getText();
       load=s6.getText();
       cds=s5.getText();
       sdcr=s2.getText();
       sds=s3.getText();
       cdt=s4.getText();

       float sdt1,tt1,dd2,load1,a,b,c,dis,sq,d1,cds1,sdcr1,width,d4,sds1,cc,aa,d3,t11,bending,bmax,bend,cdt1;
       sdt1=Float.parseFloat(sdt);
       tt1=Float.parseFloat(t);
       dd2=Float.parseFloat(d2);
       load1=Float.parseFloat(load);
       cds1=Float.parseFloat(cds);
       sdcr1=Float.parseFloat(sdcr);
       sds1=Float.parseFloat(sds);
       cdt1=Float.parseFloat(cdt);

       a=(float) (0.7853981*sdt1);
       b=(float) (tt1*-1);
       c=(float)((dd2*tt1)-(sdt1*0.78539816*(dd2*dd2))-(load1));
       dis= b * b - 4 * a * c;
       sq=(float) Math.sqrt(dis);
       d1=((b*-1) + sq)/(2*a);

       width=load1/(2*tt1*cds1);

       d4=(float)((load1+(dd2*tt1*sdcr1))/(tt1*sdcr1));

       cc=(float)((load1)/((2*sds1*d4)-(2*sds1*dd2)));

       aa=(float)((load1)/(2*sds1*dd2));

       d3=(float)(Math.sqrt((load1/(0.78539*sdcr1))+(dd2*dd2)));

       t11=(float)((load1)/(3.1415*dd2*sds1));

       bending=(float)(((load1*(d4*0.5*dd2))/(2*tt1*b*b)));

       bmax=(float)((((d4-dd2)/6)+(dd2/4))*(load1/2));
       bend = (float) Math.sqrt((6*bmax)/(t11*cdt1));

        if(e.getSource()==b2){
            t1.setText(d1 +"");
        }
        if(e.getSource()==b3){
            t2.setText(width +"");
        }
        if(e.getSource()==b4){
            t3.setText(d4 +"");
        }
        if(e.getSource()==b5){
            t4.setText(cc +"");
        }
        if(e.getSource()==b6){
            t5.setText(aa +"");
        }
        if(e.getSource()==b7){
            t6.setText(d3 +"");
        }
        if(e.getSource()==b8){
            t7.setText(t11 +"");
        }
        if(e.getSource()==b9){
            t8.setText(bending +"");
        }
        if(e.getSource()==b10){
            if(bending>sdt1){
                t9.setText("Design is not safe");
                t10.setText(bend+"");
            }
            else{t9.setText("Design is safe");}
        }
        if(e.getSource()==b1){
            d2=s7.getText();
            D1=t1.getText();
            D3=t6.getText();
            D4=t3.getText();
            T1=t7.getText();
            A=t5.getText();
            B=t10.getText();
            new Step5(d2,D1,D3,D4,T1,A,B);
        }
       
      

        
       
	}
}
