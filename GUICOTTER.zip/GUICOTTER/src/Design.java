//package app;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Design extends JFrame implements ActionListener {
    JButton b1;
    Design(String username){
        setBounds(300,30,700,700);
        getContentPane().setBackground(Color.pink);
        setLayout(null);
        
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("img/image1.png"));
        JLabel l1=new JLabel(i1);
        l1.setBounds(420,180,250,250);
        add(l1);

        JLabel k1=new JLabel("Welcome " + username +" in our GUI");
        k1.setBounds(100,40,400,50);
        k1.setFont(new Font("Times New Roman",Font.BOLD,28));
        k1.setForeground(Color.BLUE);
        add(k1);

        JLabel k2=new JLabel("");
        k2.setBounds(10,50,600,600);
        k2.setFont(new Font("Times New Roman",Font.LAYOUT_RIGHT_TO_LEFT,18));
        k2.setForeground(Color.black);
        add(k2);
        k2.setText(
        "<html>" +
            "Step 1 = Selection of Material" + "<br><br>" +
            "Select the material for Socket,Spigot and Cotter"+ "<br><br>" +
            "Calculate the Strength by Using relations of Theories of Failure"+ "<br><br>" +
            "1.Tensile yield Strength (Syt) in N/mm^2"+ "<br><br>" +
            "2.Compressive yeild Strenght (Syc) = 2*Syt N/mm^2"+ "<br><br>" +
            "3.Shear yeild Strength (Ssy) = 0.5*Syt N/mm^2"+ "<br><br>" +
            " "+ "<br><br>" +
            "Step 2 = Selection of Factor of Saftey for Socket,Spigot and Cotter"+ "<br><br>" +
            "1. Uncertainty in the magnitide of external force acting on component "+ "<br><br>" +
            "2. Variation in Properties of materials"+ "<br><br>" +
            "3. Variatioon in Diamentions of Component due to imperfect workmanship"+ "<br><br>" +
        "<html>"
        );

        b1= new JButton("Next Step");
        b1.setBounds(300,620,150,30);
        b1.setBackground(Color.WHITE);
        b1.addActionListener(this);
        add(b1);
        setVisible(true);

    }
  
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1){
            this.setVisible(false);
            new Step1();
        }
    }
}
