//package app;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Step1 extends JFrame implements ActionListener{
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,f1,f2,f3,f4,f5;
    JButton b1,b2,b3,b4,b5,b6,v1;
    
    Step1(){
        setBounds(300,30,700,700);
        Container c1 = getContentPane();
        c1.setBackground(Color.white);
        setLayout(null);
        setVisible(true);
       
        
        JLabel l3=new JLabel("3. Calculate Permissible Stresses");
        l3.setFont(new Font("Algerian",Font.BOLD, 27));
        l3.setForeground(Color.blue);
        l3.setBounds(30, 80,700, 30);
        add(l3);
        JLabel l4=new JLabel("1. Enter Value for Tensile Yeild Strength ");
        l4.setFont(new Font("Arial",Font.PLAIN, 18));
        l4.setForeground(Color.black);
        l4.setBounds(20, 140,700, 30);
        add(l4);

        t1=new JTextField();
        t1.setBounds(450,140,80,25);
        t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t1);

        JLabel l5=new JLabel("2. FOS  ");
        l5.setFont(new Font("Arial",Font.PLAIN, 18));
        l5.setForeground(Color.black);
        l5.setBounds(20, 180,700, 30);
        add(l5);
        t2=new JTextField();
        t2.setBounds(450,180,80,25);
        t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t2);

        JLabel l6=new JLabel("3. Tensile Stress = Syt/FOS  ");
        l6.setFont(new Font("Arial",Font.PLAIN, 18));
        l6.setForeground(Color.black);
        l6.setBounds(20, 220,700, 30);
        add(l6);
        b1= new JButton("Calculate");
        b1.setBounds(450, 220,80, 25);
        b1.setBackground(Color.pink);
        b1.addActionListener(this);
        add(b1);
        t3=new JTextField();
        t3.setBounds(250,260,250,25);
        t3.setBackground(Color.CYAN);
        t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t3);
        JLabel l7=new JLabel("3. Compressive Stress = (2*Syt)/FOS  ");
        l7.setFont(new Font("Arial",Font.PLAIN, 18));
        l7.setForeground(Color.black);
        l7.setBounds(20, 300,700, 30);
        add(l7);
        b2= new JButton("Calculate");
        b2.setBounds(450, 300,80, 25);
        b2.setBackground(Color.pink);
        b2.addActionListener(this);
        add(b2);
        t4=new JTextField();
        t4.setBounds(250,340,250,25);
        t4.setBackground(Color.CYAN);
        t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t4);
        JLabel l8=new JLabel("3. Shear Stress = (0.5*Syt)/FOS  ");
        l8.setFont(new Font("Arial",Font.PLAIN, 18));
        l8.setForeground(Color.black);
        l8.setBounds(20, 380,700, 30);
        add(l8);
        b3= new JButton("Calculate");
        b3.setBounds(450, 380,80, 25);
        b3.setBackground(Color.pink);
        b3.addActionListener(this);
        add(b3);
        t5=new JTextField();
        t5.setBounds(250,420,250,25);
        t5.setBackground(Color.CYAN);
        t5.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t5);
        JLabel l9=new JLabel("4. FOS for Cotter   ");
        l9.setFont(new Font("Arial",Font.PLAIN, 18));
        l9.setForeground(Color.black);
        l9.setBounds(20, 460,700, 30);
        add(l9);
        
        t6=new JTextField();
        t6.setBounds(450,460,80,25);
        t6.setBackground(Color.white);
        t6.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t6);
        JLabel l10=new JLabel("5. Tensile Stress (Cotter) = (Syt)/FOS  ");
        l10.setFont(new Font("Arial",Font.PLAIN, 18));
        l10.setForeground(Color.black);
        l10.setBounds(20, 500,700, 30);
        add(l10);
        b4= new JButton("Calculate");
        b4.setBounds(450, 500,80, 25);
        b4.setBackground(Color.pink);
        b4.addActionListener(this);
        add(b4);
        t7=new JTextField();
        t7.setBounds(250,540,250,25);
        t7.setBackground(Color.CYAN);
        t7.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t7);
        JLabel l11=new JLabel("5. Shear Stress (Cotter) = (0.5*Syt)/FOS  ");
        l11.setFont(new Font("Arial",Font.PLAIN, 18));
        l11.setForeground(Color.black);
        l11.setBounds(20, 580,700, 30);
        add(l11);
        b5= new JButton("Calculate");
        b5.setBounds(450, 580,80, 25);
        b5.setBackground(Color.pink);
        b5.addActionListener(this);
        add(b5);
        t8=new JTextField();
        t8.setBounds(250,620,250,25);
        t8.setBackground(Color.CYAN);
        t8.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t8);
        b6= new JButton("next");
        b6.setBounds(550, 20,80, 25);
        b6.setBackground(Color.cyan);
        b6.addActionListener(this);
        add(b6);
        

     }
    // public static void main(String[] args){
    //     new Step1();
        
    
    // }
	@Override
	public void actionPerformed(ActionEvent e) {
		String a,b,c,tens,crush,shear, ct,cs;
        a=t1.getText(); //tensile yeild strength
        b=t2.getText(); //fos for socket & spigot
        c=t6.getText(); //fos for cotter
        
        Float a1,a2,a3;
        a1=Float.parseFloat(a);
        a2=Float.parseFloat(b);
        a3=Float.parseFloat(c);
       

        if(e.getSource()==b1){
            t3.setText(Math.round(a1/a2)+""); //tensile stress (socket sdt)

        }
        if(e.getSource()==b2){
            t4.setText(Math.round((2*a1)/a2)+""); //crushing stress (socket sdc)

        }
        if(e.getSource()==b3){
            t5.setText(Math.round((0.5*a1)/a2)+""); //shear stress (socket sds)

        }
        if(e.getSource()==b4){
            t7.setText(Math.round((a1)/a3)+""); //tensile stresss for cotter (cotter sdt)

         }
        if(e.getSource()==b5){
            t8.setText((Math.round(0.5*a1)/a3)+""); //sher stress for cotter (cotter sds)

         } 
        if(e.getSource()==b6){
            tens =t3.getText(); //tesile stress
           
            crush=t4.getText();//crushing
            shear=t5.getText();
            ct=t7.getText();
            cs=t8.getText();
            this.setVisible(false);
            new Step2(tens,crush,shear,ct,cs);
          
         } 
        
	}
    
}
