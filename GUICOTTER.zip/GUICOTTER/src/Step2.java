//package app;
import javax.swing.JFrame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Step2 extends JFrame implements ActionListener{
    JTextField t1,t2,t3,t4,t5,t6,t7,t8,s1,s2,s3,s4,s5;
    JButton b1,b2,b3,b4,b5,b6;
    Step2(String stress,String cr,String sh, String ct,String cs){
    
        setBounds(300,30,700,700);
        getContentPane().setBackground(Color.white);
        setLayout(null);
        setVisible(true);
        JLabel l9=new JLabel("Stresses are ");
        l9.setFont(new Font("Times New Roman",Font.BOLD, 18));
        l9.setForeground(Color.blue);
        l9.setBounds(20, 10,700, 30);
        add(l9);
        s1=new JTextField(stress);
        s1.setBounds(120,10,100,25);
        s1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s1);
        s2=new JTextField(cr);
        s2.setBounds(230,10,100,25);
        s2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s2);
        s3=new JTextField(sh);
        s3.setBounds(340,10,100,25);
        s3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s3);
        s4=new JTextField(ct);
        s4.setBounds(450,10,100,25);
        s4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s4);
        s5=new JTextField(cs);
        s5.setBounds(560,10,100,25);
        s5.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(s5);
        JLabel l3=new JLabel("Step 1 = Tensile Failure of Socket rod");
        l3.setFont(new Font("Algerian",Font.BOLD, 20));
        l3.setForeground(Color.blue);
        l3.setBounds(30, 80,700, 30);
        add(l3);
        JLabel l4=new JLabel("1. Enter Value for Tensile Force ");
        l4.setFont(new Font("Arial",Font.PLAIN, 18));
        l4.setForeground(Color.black);
        l4.setBounds(20, 140,700, 30);
        add(l4);
        t1=new JTextField();
        t1.setBounds(450,140,80,25);
        t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t1);
        JLabel l5=new JLabel("2. Diameter of Rod (d) ");
        l5.setFont(new Font("Arial",Font.PLAIN, 18));
        l5.setForeground(Color.black);
        l5.setBounds(20, 180,700, 30);
        add(l5);
        b1= new JButton("Calculate");
        b1.setBounds(450, 180,80, 25);
        b1.setBackground(Color.pink);
        b1.addActionListener(this);
        add(b1);
        t2=new JTextField();
        t2.setBounds(250,180,120,25);
        t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t2);
        ImageIcon i1= new ImageIcon(ClassLoader.getSystemResource("img/dia.png"));
        JLabel j1=new JLabel(i1);
        j1.setBounds(80,220,550,350);
        add(j1);
        b4= new JButton("next");
        b4.setBounds(570, 40,80, 25);
        b4.setBackground(Color.cyan);
        b4.addActionListener(this);
        add(b4);
        JLabel l7=new JLabel("Step 2  - Failure of Spigot in tension across the weakest section");
        l7.setFont(new Font("Algerian",Font.BOLD, 18));
        l7.setForeground(Color.blue);
        l7.setBounds(30, 550,700, 30);
        add(l7);
        JLabel l6=new JLabel("2. Diameter of Spigot (d2) ");
        l6.setFont(new Font("Arial",Font.PLAIN, 18));
        l6.setForeground(Color.black);
        l6.setBounds(20, 575,700, 30);
        add(l6);
        b2= new JButton("Calculate");
        b2.setBounds(450, 575,80, 25);
        b2.setBackground(Color.pink);
        b2.addActionListener(this);
        add(b2);
        t3=new JTextField();
        t3.setBounds(250,575,120,25);
        t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t3);
        JLabel l8=new JLabel("2. Thickness of Cotter (t) ");
        l8.setFont(new Font("Arial",Font.PLAIN, 18));
        l8.setForeground(Color.black);
        l8.setBounds(20, 610,700, 30);
        add(l8);
        b3= new JButton("Calculate");
        b3.setBounds(450, 610,80, 25);
        b3.setBackground(Color.pink);
        b3.addActionListener(this);
        add(b3);
        t4=new JTextField();
        t4.setBounds(250,610,120,25);
        t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
        add(t4);
     
        
    }
    // public static void main(String[]args){
    //     new Step2("","","","","");
    // }
    @Override
	public void actionPerformed(ActionEvent e) {
        String a,b,c,tens,crush,shear,ct,cs,load,d2,t;
        b=t1.getText(); //load
        a=s1.getText(); //tesile stress
        c=t3.getText(); //d2
        int a1;
        a1=Integer.parseInt(b);
        float c1;
        c1=Float.parseFloat(a);
        double a2;
        a2=Double.parseDouble(c);
        
        
        if(e.getSource()==b1){
            t2.setText((float) Math.sqrt((4*a1)/(3.14*c1))+"");
        }

        if(e.getSource()==b2){
            t3.setText((float) (Math.sqrt(a1/c1*1.867768828))+"");
        }
      
      
        if(e.getSource()==b3){
            t4.setText((a2/4)+"");
        }
        if(e.getSource()==b4){
            tens=s1.getText();
            crush=s2.getText();
            shear=s3.getText();
            ct=s4.getText();
            cs=s5.getText();
            load=t1.getText();
            d2=t3.getText();
            t=t4.getText();
            this.setVisible(false);
            new Step3(tens,crush,shear,ct,cs,load,d2,t);
        }
    }
    
}

